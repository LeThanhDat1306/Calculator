﻿using Calculator;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace CalculatorTester
{
    [TestClass]
    public class BaiTapUnitTest
    {
        public TestContext TestContext { get; set; }
        [TestMethod]
        public void TestPower1()
        {
            double x = 1;
            int n = 0;
            double expected = 1;
            Assert.AreEqual(expected,BaiTap.Power(x,n));
        }
        [TestMethod]
        public void TestPower2()
        {
            double x = 3;
            int n = 2;
            double expected = 9;
            Assert.AreEqual(expected, BaiTap.Power(x, n));
        }
        [TestMethod]
        public void TestPower3()
        {
            double x = 2;
            int n = -1;
            double expected = 0.5;
            Assert.AreEqual(expected, BaiTap.Power(x, n));
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestPolyn1()
        {
            int n = 2;
            List<int> a = new List<int> { 1, 2 };
            Polynomial p = new Polynomial(n, a);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestPolyn2()
        {
            int n = 2;
            List<int> a = new List<int> { 1, 2, 3, 4 };
            Polynomial p = new Polynomial(n, a);
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestPolyn3()
        {
            int n = -1;
            List<int> a = new List<int> { };
            Polynomial p = new Polynomial(n, a);
        }
        [TestMethod]
        public void TestPolyn4()
        {
            int n = 2;
            List<int> a = new List<int> { 1, 2, 3 };
            int x = 1;
            int expected = 6;
            Polynomial p = new Polynomial(n, a);
            Assert.AreEqual(expected, p.Cal(x));
        }
        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV",
 @".\Data\TestData3.csv", "TestData3#csv", DataAccessMethod.Sequential)]
        [TestMethod]
        public void TestRadix3()
        {
            int number = int.Parse(TestContext.DataRow[0].ToString());
            int radix = int.Parse(TestContext.DataRow[1].ToString());
            string expected = TestContext.DataRow[2].ToString();
            Radix r = new Radix(number);
            Assert.AreEqual(expected, r.ConvertDecimalToAnother(radix));
        }
    }
}
