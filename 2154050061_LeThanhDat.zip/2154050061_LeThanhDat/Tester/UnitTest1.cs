﻿using _2154050061_LeThanhDat;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Tester
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestSort1()
        {
            /*input 2,1,3,6,5,4
             output = 1,2,3,4,5,6 */
            int[] mang = { 1, 2, 3, 4, 5, 6 };
            int[] expected =  { 1, 2, 3, 4, 5, 6};
            CollectionAssert.AreEqual(Class1.SortOptimizedArray(mang, 6), expected);
        }
        public void TestSort2()
        {
            /*input 1,2,3,4,5,6
             output = 1,2,3,4,5,6 */
            int[] mang = { 1, 2, 3, 4, 5, 6 };
            int[] expected = { 1, 2, 3, 4, 5, 6};
            CollectionAssert.AreEqual(Class1.SortOptimizedArray(mang, 6), expected);
        }
        public void TestSort3()
        {
            /*input = 
             output = */
            int[] mang = { };
            int[] expected = { };
            CollectionAssert.AreEqual(Class1.SortOptimizedArray(mang, 6), expected);
        }
    }
}
